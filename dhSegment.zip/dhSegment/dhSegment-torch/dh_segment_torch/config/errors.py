class ConfigurationError(Exception):
    pass


class RegistrableError(Exception):
    pass