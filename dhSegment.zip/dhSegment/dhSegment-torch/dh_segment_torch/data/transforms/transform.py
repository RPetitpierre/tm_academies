from dh_segment_torch.config.registrable import Registrable


class Transform(Registrable):
    pass
    # def __init__(self):
    #     pass
